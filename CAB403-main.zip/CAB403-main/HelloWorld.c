#include <stdio.h>

int main()
{
    printf("Hello, please tell me this is working");
    // sleep(3);
    return 0;
    // char myChar;
    // printf("Please enter a character");
    // scanf("%c", myChar);
    // printf("The integer valued entered was is %d\n", myChar);
    // return 0;
}
