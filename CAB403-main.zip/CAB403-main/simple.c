#include <stdio.h>
#include <unistd.h>

int main(int argc, char** argv)
{
    printf("Received arguement: %s, %s\n", argv[1], argv[2]);
}